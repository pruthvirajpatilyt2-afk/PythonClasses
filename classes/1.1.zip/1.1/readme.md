make a bank account manager.
which has account hoder imfo
bank balance.
deposite/ widrow money
check balance
transiction history
multi costmr

aacc type 
5-saving
6-current
7-merchant
8-depo
9-widrw