class Imfo:
    def __init__(self):
        self.name='name'
        self.version='1.0.0.0'
        self.title=f'{self.name} {self.version}'
        print(self.title)