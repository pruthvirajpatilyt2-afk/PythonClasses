from customtkinter import *
class screen(CTk):
    def __init__(self, fg_color = None, tle=None, **kwargs):
        super().__init__(fg_color, **kwargs)
        self.tle=tle
        
    def show(self):
        self.title(self.tle)
        print(self.tle)
        self.mainloop()