from app.imfo import Imfo
from ui.loading_screen import screen

class app(Imfo, screen):
    def __init__(self):
        Imfo.__init__(self)  # Correct: initialize Imfo part of self
        screen.__init__(self, tle=self.title)  # Correct: initialize screen part of self
        self.show()
